CYBER DEFENSE DAY — SISTEMA PRÓPRIO DE SORTEIO

REQUISITOS
- Hospedagem com PHP 8+ (cPanel funciona normalmente).
- A pasta data precisa ter permissão de escrita para o PHP.
- Não usa MySQL.
- Não depende da Sympla.
- O QR Code é gerado localmente pelo próprio PHP (arquivo qr.php), sem API externa.

INSTALAÇÃO
1. Envie todos os arquivos desta pasta para o cPanel, por exemplo:
   public_html/sorteio/
2. Acesse:
   https://seudominio.com/sorteio/
3. Entre no painel administrativo.
4. O sistema detecta automaticamente a URL do cadastro e gera o QR Code.

SENHA INICIAL DO PAINEL
Cyber@2026!

IMPORTANTE: altere ADMIN_PASSWORD em config.php antes de usar no evento.

FLUXO DO PARTICIPANTE
1. Escaneia o QR Code exibido no painel.
2. Informa Nome e Sobrenome.
3. Recebe um ID único no formato CDD-XXXXXX.
4. O navegador guarda o ID e, se a pessoa abrir novamente, exibe o mesmo cadastro.

FLUXO DO SORTEIO
1. O painel mostra a quantidade de participantes cadastrados.
2. Clique em SORTEAR.
3. O sistema executa contagem regressiva 3-2-1 com som.
4. Faz a animação de IDs.
5. Exibe ID sorteado + nome da pessoa.
6. Dispara efeito de confetes e som de vencedor.
7. O ganhador é removido dos próximos sorteios, salvo se ALLOW_REPEAT_WINNERS for alterado.

MODO TELÃO
- Use o botão “MODO TELÃO” para colocar apenas a área do sorteio em tela cheia.
- ESC sai da tela cheia.
- O botão “Som: ON/OFF” controla os efeitos sonoros.

CONFIGURAÇÕES EM config.php
- ADMIN_PASSWORD: senha do painel.
- ID_PREFIX: prefixo dos IDs (padrão CDD).
- ALLOW_REPEAT_WINNERS: false impede que alguém ganhe novamente.
- REGISTRATION_OPEN: false encerra novos cadastros.
- PUBLIC_REGISTRATION_URL: opcional. Deixe vazio para detectar automaticamente.

ARMAZENAMENTO
- data/participants.json: participantes.
- data/winners.json: histórico de sorteios.
- data/.htaccess: bloqueia acesso web direto aos arquivos JSON em Apache/cPanel.

TESTE RECOMENDADO ANTES DO EVENTO
1. Abra o painel no notebook do telão.
2. Escaneie o QR com 2 ou 3 celulares.
3. Confirme que os participantes aparecem no painel.
4. Faça sorteios de teste.
5. Limpe o histórico antes do evento oficial.
6. Troque a senha padrão.
