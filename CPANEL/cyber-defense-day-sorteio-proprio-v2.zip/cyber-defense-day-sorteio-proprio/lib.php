<?php
require_once __DIR__ . '/config.php';

function data_file(string $name): string {
    return __DIR__ . '/data/' . $name . '.json';
}

function ensure_data_files(): void {
    foreach (['participants','winners'] as $name) {
        $file = data_file($name);
        if (!file_exists($file)) {
            @file_put_contents($file, "[]", LOCK_EX);
        }
    }
}

function read_json_locked(string $name): array {
    ensure_data_files();
    $file = data_file($name);
    $fp = fopen($file, 'c+');
    if (!$fp) return [];
    flock($fp, LOCK_SH);
    rewind($fp);
    $raw = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}

function mutate_json_locked(string $name, callable $callback) {
    ensure_data_files();
    $file = data_file($name);
    $fp = fopen($file, 'c+');
    if (!$fp) throw new RuntimeException('Não foi possível abrir o armazenamento.');
    if (!flock($fp, LOCK_EX)) throw new RuntimeException('Não foi possível bloquear o armazenamento.');
    rewind($fp);
    $raw = stream_get_contents($fp);
    $data = json_decode($raw ?: '[]', true);
    if (!is_array($data)) $data = [];
    $result = $callback($data);
    rewind($fp);
    ftruncate($fp, 0);
    fwrite($fp, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return $result;
}

function clean_name(string $value): string {
    $value = trim(preg_replace('/\s+/u', ' ', $value));
    return function_exists('mb_substr') ? mb_substr($value, 0, 80, 'UTF-8') : substr($value, 0, 80);
}

function valid_name(string $value): bool {
    return (bool)preg_match('/^[\p{L}][\p{L}\p{M}\s\'\-\.]{1,79}$/u', $value);
}

function generate_unique_id(array $participants): string {
    $existing = [];
    foreach ($participants as $p) $existing[$p['id'] ?? ''] = true;
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    do {
        $code = '';
        for ($i=0; $i<6; $i++) $code .= $alphabet[random_int(0, strlen($alphabet)-1)];
        $id = ID_PREFIX . '-' . $code;
    } while (isset($existing[$id]));
    return $id;
}

function registration_url(): string {
    if (PUBLIC_REGISTRATION_URL !== '') return PUBLIC_REGISTRATION_URL;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme . '://' . $host . ($dir ? $dir : '') . '/cadastro.php';
}

function json_response(array $payload, int $code=200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}

function start_secure_session(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'httponly'=>true,
            'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'samesite'=>'Lax'
        ]);
        session_start();
    }
}

function require_admin(): void {
    start_secure_session();
    if (empty($_SESSION['cdd_admin'])) json_response(['ok'=>false,'error'=>'Não autorizado.'], 401);
}
