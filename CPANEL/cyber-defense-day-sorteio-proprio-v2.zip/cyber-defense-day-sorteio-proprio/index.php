<?php
require_once __DIR__ . '/lib.php';
start_secure_session();
$error='';
if (isset($_GET['logout'])) { session_destroy(); header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['password']) && empty($_SESSION['cdd_admin'])) {
    if (hash_equals(ADMIN_PASSWORD, (string)$_POST['password'])) { $_SESSION['cdd_admin']=true; header('Location: index.php'); exit; }
    $error='Senha incorreta.';
}
if (empty($_SESSION['cdd_admin'])):
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Painel | <?=htmlspecialchars(EVENT_NAME)?></title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;background:#040912 url('assets/brand-banner.png') center/cover fixed;font-family:Inter,Segoe UI,Arial,sans-serif;color:#eef8ff}body:before{content:"";position:fixed;inset:0;background:rgba(2,7,13,.82)}.box{position:relative;width:min(440px,100%);padding:28px;border:1px solid #20547c;border-radius:22px;background:rgba(4,13,24,.94);box-shadow:0 20px 70px #000}.logo{width:100px;margin:auto}.logo img{width:100%}h1{text-align:center;margin:14px 0 4px}p{text-align:center;color:#8faac0}input{width:100%;padding:14px;border:1px solid #245273;border-radius:12px;background:#071522;color:white;font-size:16px}button{width:100%;padding:14px;margin-top:12px;border:0;border-radius:12px;background:linear-gradient(135deg,#0d82ff,#55dfff);font-weight:1000;color:#03111c}.err{color:#ff98a7;text-align:center;margin-bottom:10px}
#confettiCanvas{position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:9999;display:none}
.toplinks{display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end}.toplinks .secondary,.toplinks a{font-size:12px}.toplinks a{border:1px solid #244965;background:#071522;color:#cce6f7;padding:8px 11px;border-radius:10px}
.stagebrand{display:none;position:absolute;top:34px;left:50%;transform:translateX(-50%);align-items:center;gap:16px;z-index:3}.stagebrand img{width:92px;filter:drop-shadow(0 0 20px #1dafff77)}.stagebrand strong{display:block;font-size:clamp(26px,4vw,54px);line-height:.92}.stagebrand span{color:var(--cyan)}
.countdown{position:absolute;inset:0;display:none;align-items:center;justify-content:center;z-index:8;background:radial-gradient(circle at 50% 50%,rgba(14,91,143,.35),rgba(2,7,13,.93) 55%);font-size:clamp(110px,22vw,270px);font-weight:1000;color:#fff;text-shadow:0 0 35px #2ec8ff,0 0 90px #0a82ff;user-select:none}.countdown.show{display:flex}.countdown.pop{animation:countPop .72s ease both}@keyframes countPop{0%{transform:scale(.35);opacity:0}35%{transform:scale(1.16);opacity:1}100%{transform:scale(.9);opacity:.15}}
.stage-actions{display:flex;gap:10px;align-items:center;justify-content:center;flex-wrap:wrap;position:relative}.stage-actions .secondary{margin-top:24px;padding:13px 16px}.stage-status{position:relative;margin-top:12px;color:#7e99b1;font-size:12px;min-height:17px}
body.theater{overflow:hidden;background:#02070d}.theater .app{max-width:none;padding:0}.theater .hero,.theater .grid>section:first-child,.theater .history{display:none!important}.theater .grid{display:block;margin:0}.theater .stage{position:fixed;inset:0;z-index:5000;border:0;border-radius:0;min-height:100vh;background:radial-gradient(circle at 50% 40%,#0b3154 0,#06111e 38%,#02060c 78%);padding-top:150px}.theater .stage:before{opacity:.08;background-size:min(44vw,560px)}.theater .stagebrand{display:flex}.theater .label{font-size:16px}.theater .id{font-size:clamp(80px,12vw,180px);margin:30px 0 12px}.theater .name{font-size:clamp(42px,6vw,88px);min-height:100px}.theater .btn{font-size:30px;padding:20px 58px}.theater .stage-actions .secondary{font-size:18px;padding:16px 22px}.theater .stage-status{font-size:15px}.theater-exit{display:none;position:fixed;top:18px;right:20px;z-index:7000;border:1px solid #2b678e;background:#071522dd;color:#d8efff;padding:10px 14px;border-radius:10px;cursor:pointer}.theater .theater-exit{display:block}
.qr-note{margin-top:8px;color:#6f91ac;font-size:11px}.qr-actions{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}.qr-actions a{text-decoration:none}
@media(max-width:900px){.toplinks{display:none}.stagebrand{top:20px}.theater .stage{padding-top:120px}.theater .stagebrand img{width:70px}}
</style></head><body><form class="box" method="post"><div class="logo"><img src="assets/brand-emblem.png"></div><h1>CYBER DEFENSE DAY</h1><p>Painel administrativo do sorteio</p><?php if($error):?><div class="err"><?=htmlspecialchars($error)?></div><?php endif;?><input type="password" name="password" placeholder="Senha do administrador" required autofocus><button>ENTRAR</button></form></body></html>
<?php exit; endif; ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sorteio Oficial | <?=htmlspecialchars(EVENT_NAME)?></title>
<style>
:root{--bg:#050a12;--panel:#071421;--line:#1d4f78;--cyan:#56dcff;--blue:#0a82ff;--text:#f1f9ff;--muted:#91a9bf;--ok:#53dba7;--danger:#ff8594}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 50% 0,#0b2b4c 0,#06111e 32%,#03070d 82%);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif;min-height:100vh}.app{max-width:1260px;margin:auto;padding:22px}.hero{min-height:220px;border:1px solid rgba(81,165,224,.3);border-radius:24px;background:linear-gradient(90deg,rgba(3,10,18,.9),rgba(3,10,18,.55)),url('assets/brand-banner.png') center/cover;display:flex;align-items:center;padding:26px;box-shadow:0 24px 60px #0008}.hero-inner{display:flex;align-items:center;gap:18px}.hero img{width:112px;filter:drop-shadow(0 0 18px #1dafff55)}h1{margin:0;font-size:clamp(36px,6vw,68px);line-height:.95}.cyan{color:var(--cyan)}.hero p{color:#c1d9eb;margin:9px 0 0}.toplinks{margin-left:auto;align-self:flex-start}.toplinks a{color:#acd5ef;text-decoration:none;font-size:13px}.grid{display:grid;grid-template-columns:.92fr 1.08fr;gap:18px;margin-top:18px}.card{border:1px solid rgba(79,160,216,.27);border-radius:22px;background:linear-gradient(180deg,rgba(7,20,33,.96),rgba(4,13,23,.97));padding:20px;box-shadow:0 18px 50px #0005}.card h2{margin:0 0 14px;font-size:18px}.qrbox{display:flex;gap:18px;align-items:center;flex-wrap:wrap}.qr{width:230px;height:230px;background:#fff;border-radius:16px;padding:12px;display:grid;place-items:center}.qr img{width:100%;height:100%;object-fit:contain}.url{flex:1;min-width:240px}.urlcode{word-break:break-all;padding:12px;border-radius:12px;border:1px solid #214d6f;background:#06121f;color:#bdeaff}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:16px}.stat{border:1px solid #174263;background:#06121f;border-radius:14px;padding:14px;text-align:center}.stat b{display:block;color:var(--cyan);font-size:30px}.stat span{font-size:12px;color:var(--muted)}.stage{min-height:500px;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;position:relative;overflow:hidden}.stage:before{content:"";position:absolute;inset:0;background:url('assets/brand-emblem.png') center/300px no-repeat;opacity:.05}.label{position:relative;color:#849eb5;font-size:12px;letter-spacing:.22em;text-transform:uppercase}.id{position:relative;margin:25px 0 10px;font-size:clamp(44px,8vw,92px);font-weight:1000;color:var(--cyan);text-shadow:0 0 24px #19b9ff55}.name{position:relative;font-size:clamp(24px,4vw,42px);font-weight:1000;min-height:52px}.btn{position:relative;margin-top:24px;border:0;border-radius:15px;padding:16px 42px;background:linear-gradient(135deg,var(--blue),var(--cyan));color:#03111c;font-size:21px;font-weight:1000;cursor:pointer;box-shadow:0 14px 30px #0a86ff33}.btn:disabled{opacity:.45;cursor:not-allowed}.latest{margin-top:18px}.list{display:grid;gap:8px}.person{display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid #173d5a;background:#06121f;border-radius:12px;padding:10px 12px}.person strong{color:#dff5ff}.person small{color:#8ca5b9}.pill{font-family:monospace;color:#63deff}.mini{border:0;background:#192a39;color:#cde2f3;border-radius:8px;padding:6px 8px;cursor:pointer}.history{margin-top:18px}.history-table{width:100%;border-collapse:collapse}.history-table th,.history-table td{text-align:left;padding:10px;border-bottom:1px solid #153753;font-size:13px}.history-table th{color:#9eb9cd}.rowhead{display:flex;justify-content:space-between;gap:12px;align-items:center}.secondary{border:1px solid #244965;background:#071522;color:#cce6f7;padding:8px 11px;border-radius:10px;cursor:pointer}@media(max-width:900px){.grid{grid-template-columns:1fr}.toplinks{display:none}.hero-inner{align-items:flex-start}.hero img{width:80px}.qrbox{justify-content:center}.url{width:100%}.stage{min-height:380px}}@media(max-width:560px){.app{padding:12px}.hero{padding:18px;min-height:180px}.hero-inner{gap:12px}.hero img{width:64px}.stats{grid-template-columns:repeat(3,1fr)}.qr{width:210px;height:210px}}
</style></head><body><canvas id="confettiCanvas"></canvas><button class="theater-exit" onclick="toggleTheater()">✕ Sair do telão</button><div class="app"><section class="hero"><div class="hero-inner"><img src="assets/brand-emblem.png" alt="Brasão"><div><h1>CYBER <span class="cyan">DEFENSE DAY</span></h1><p>Sorteio próprio por ID • Cadastro via QR Code</p></div></div><div class="toplinks"><button class="secondary" type="button" onclick="toggleSound()" id="soundBtn">🔊 Som: ON</button><button class="secondary" type="button" onclick="toggleTheater()">⛶ MODO TELÃO</button><a href="?logout=1">Sair do painel</a></div></section>
<div class="grid"><section class="card"><h2>QR Code de cadastro</h2><div class="qrbox"><div class="qr"><img id="qrImage" alt="QR Code"></div><div class="url"><p style="color:#9fb6c9">Peça aos participantes para apontarem a câmera do celular para o QR Code.</p><div id="regUrl" class="urlcode">Carregando endereço...</div><div class="qr-actions"><button class="secondary" type="button" onclick="copyRegistrationUrl()">Copiar link</button><a id="openRegistration" class="secondary" target="_blank" rel="noopener">Abrir cadastro</a></div><div class="qr-note">QR Code gerado no próprio servidor, sem serviço externo.</div><div class="stats"><div class="stat"><b id="count">0</b><span>Participantes</span></div><div class="stat"><b id="winnerCount">0</b><span>Sorteados</span></div><div class="stat"><b id="remaining">0</b><span>Aptos</span></div></div></div></div><div class="latest"><div class="rowhead"><h2 style="margin:0">Últimos cadastros</h2><button class="secondary" onclick="refreshStatus()">Atualizar</button></div><div id="latest" class="list" style="margin-top:10px"><div style="color:#8ea6ba">Nenhum participante ainda.</div></div></div></section>
<section class="card stage" id="stage"><div class="stagebrand"><img src="assets/brand-emblem.png" alt="Brasão"><strong>CYBER <span>DEFENSE DAY</span></strong></div><div id="countdown" class="countdown">3</div><div class="label">ID sorteado</div><div id="drawId" class="id">—</div><div id="drawName" class="name"></div><div class="stage-actions"><button id="drawBtn" class="btn" onclick="drawWinner()" disabled>SORTEAR</button><button class="secondary" type="button" onclick="toggleTheater()">⛶ TELÃO</button></div><div id="stageStatus" class="stage-status"></div></section></div>
<section class="card history"><div class="rowhead"><h2 style="margin:0">Histórico de sorteios</h2><button class="secondary" onclick="resetWinners()">Limpar histórico</button></div><div style="overflow:auto;margin-top:10px"><table class="history-table"><thead><tr><th>#</th><th>Data/Hora</th><th>ID</th><th>Nome</th></tr></thead><tbody id="historyBody"><tr><td colspan="4" style="color:#859eb3;text-align:center">Nenhum sorteio realizado.</td></tr></tbody></table></div></section></div>
<script>
let participantCount=0,winnerCount=0,lastRegUrl='',soundEnabled=true,audioCtx=null,drawing=false;
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

function audio(){if(!soundEnabled)return null;if(!audioCtx)audioCtx=new(window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();return audioCtx}
function tone(freq=660,duration=.12,type='sine',gain=.07,delay=0){const a=audio();if(!a)return;const o=a.createOscillator(),g=a.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(0.0001,a.currentTime+delay);g.gain.exponentialRampToValueAtTime(gain,a.currentTime+delay+.012);g.gain.exponentialRampToValueAtTime(.0001,a.currentTime+delay+duration);o.connect(g);g.connect(a.destination);o.start(a.currentTime+delay);o.stop(a.currentTime+delay+duration+.03)}
function tickSound(n){tone(n===1?880:610,.13,'square',.045)}
function winnerSound(){tone(523,.18,'sine',.07,0);tone(659,.18,'sine',.07,.12);tone(784,.22,'sine',.075,.24);tone(1046,.38,'sine',.08,.38)}
function toggleSound(){soundEnabled=!soundEnabled;$('soundBtn').textContent=soundEnabled?'🔊 Som: ON':'🔇 Som: OFF';if(soundEnabled)audio()}

async function refreshStatus(){
  try{
    const r=await fetch('api.php?action=status',{cache:'no-store'}),d=await r.json();if(!d.ok)return;
    participantCount=d.count;winnerCount=d.winners;
    $('count').textContent=d.count;$('winnerCount').textContent=d.winners;$('remaining').textContent=Math.max(0,d.count-d.winners);
    $('drawBtn').disabled=drawing||(d.count-d.winners)<=0;
    $('regUrl').textContent=d.registration_url;$('openRegistration').href=d.registration_url;
    if(lastRegUrl!==d.registration_url){lastRegUrl=d.registration_url;$('qrImage').src='qr.php?u='+encodeURIComponent(d.registration_url)+'&v='+Date.now();}
    $('latest').innerHTML=d.latest.length?d.latest.map(p=>`<div class="person"><div><strong>${esc(p.name)}</strong><br><small>${new Date(p.created_at).toLocaleString('pt-BR')}</small></div><div><span class="pill">${esc(p.id)}</span> <button class="mini" onclick="deleteParticipant('${esc(p.id)}')">✕</button></div></div>`).join(''):'<div style="color:#8ea6ba">Nenhum participante ainda.</div>';
  }catch(e){$('stageStatus').textContent='Falha ao atualizar o painel.'}
}
function copyRegistrationUrl(){navigator.clipboard?.writeText(lastRegUrl).then(()=>{$('stageStatus').textContent='Link de cadastro copiado.';setTimeout(()=>{$('stageStatus').textContent=''},1800)}).catch(()=>prompt('Copie o link:',lastRegUrl))}

async function runCountdown(){
  const el=$('countdown');el.classList.add('show');
  for(const n of [3,2,1]){el.textContent=n;el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop');tickSound(n);await sleep(760)}
  el.textContent='SORTEIO';el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop');tone(980,.17,'square',.05);await sleep(520);el.classList.remove('show','pop');
}
function randomFakeId(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let x='CDD-';for(let i=0;i<6;i++)x+=chars[Math.floor(Math.random()*chars.length)];return x}

async function drawWinner(){
  if(drawing)return; audio(); drawing=true; const b=$('drawBtn');b.disabled=true;$('drawName').textContent='';$('stageStatus').textContent='Preparando sorteio...';
  try{
    await runCountdown();
    $('stageStatus').textContent='Sorteando...';
    const request=fetch('api.php?action=draw',{method:'POST'}).then(r=>r.json());
    const spin=setInterval(()=>{$('drawId').textContent=randomFakeId();tone(250+Math.random()*190,.035,'square',.012)},62);
    await sleep(1450);
    const d=await request;clearInterval(spin);
    if(!d.ok){alert(d.error||'Erro no sorteio');$('stageStatus').textContent='';drawing=false;refreshStatus();return;}
    $('drawId').textContent=d.winner.id;$('drawName').textContent=d.winner.name;$('stageStatus').textContent='🎉 GANHADOR(A)';winnerSound();launchConfetti();
    await refreshStatus();await loadHistory();
  }catch(e){alert('Falha de comunicação com o servidor.');$('stageStatus').textContent='';}
  finally{drawing=false;refreshStatus()}
}
async function loadHistory(){try{const r=await fetch('api.php?action=history',{cache:'no-store'}),d=await r.json(),tb=$('historyBody');if(!d.ok||!d.items.length){tb.innerHTML='<tr><td colspan="4" style="color:#859eb3;text-align:center">Nenhum sorteio realizado.</td></tr>';return;}tb.innerHTML=d.items.map((w,i)=>`<tr><td>${d.items.length-i}</td><td>${new Date(w.drawn_at).toLocaleString('pt-BR')}</td><td class="pill">${esc(w.id)}</td><td>${esc(w.name)}</td></tr>`).join('')}catch(e){}}
async function deleteParticipant(id){if(!confirm('Excluir '+id+' da lista?'))return;const fd=new FormData();fd.append('id',id);await fetch('api.php?action=delete_participant',{method:'POST',body:fd});refreshStatus()}
async function resetWinners(){if(!confirm('Limpar o histórico e permitir novos sorteios?'))return;await fetch('api.php?action=reset_winners',{method:'POST'});$('drawId').textContent='—';$('drawName').textContent='';$('stageStatus').textContent='';refreshStatus();loadHistory()}

async function toggleTheater(){
  const goingOn=!document.body.classList.contains('theater');
  if(goingOn){document.body.classList.add('theater');try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen()}catch(e){}}
  else{document.body.classList.remove('theater');try{if(document.fullscreenElement)await document.exitFullscreen()}catch(e){}}
}
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)document.body.classList.remove('theater')});

function launchConfetti(){
  const canvas=$('confettiCanvas'),ctx=canvas.getContext('2d');canvas.style.display='block';canvas.width=innerWidth*devicePixelRatio;canvas.height=innerHeight*devicePixelRatio;ctx.scale(devicePixelRatio,devicePixelRatio);
  const colors=['#56dcff','#0a82ff','#ffffff','#8be8ff','#1fb6ff'];
  const parts=Array.from({length:180},()=>({x:innerWidth/2+(Math.random()-.5)*160,y:innerHeight*.35,vx:(Math.random()-.5)*13,vy:-Math.random()*13-4,g:.28+Math.random()*.16,r:3+Math.random()*5,a:Math.random()*Math.PI*2,va:(Math.random()-.5)*.28,c:colors[Math.floor(Math.random()*colors.length)],life:0}));
  const start=performance.now();
  function frame(t){ctx.clearRect(0,0,innerWidth,innerHeight);for(const p of parts){p.x+=p.vx;p.y+=p.vy;p.vy+=p.g;p.a+=p.va;p.life++;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.a);ctx.fillStyle=p.c;ctx.fillRect(-p.r,-p.r*.45,p.r*2,p.r*.9);ctx.restore()}if(t-start<4300)requestAnimationFrame(frame);else{ctx.clearRect(0,0,innerWidth,innerHeight);canvas.style.display='none'}}requestAnimationFrame(frame)
}

refreshStatus();loadHistory();setInterval(refreshStatus,4000);
</script></body></html>
