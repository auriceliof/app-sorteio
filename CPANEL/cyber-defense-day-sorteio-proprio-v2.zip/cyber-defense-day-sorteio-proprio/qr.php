<?php
// Gerador de QR Code local (SVG), sem dependências externas.
// Implementação compacta para URLs em modo Byte, correção de erro L, versões 1 a 10.
require_once __DIR__ . '/lib.php';

header('Content-Type: image/svg+xml; charset=utf-8');
header('Cache-Control: no-store');

$data = registration_url();
if (isset($_GET['u']) && is_string($_GET['u']) && $_GET['u'] !== '') {
    $candidate = trim($_GET['u']);
    if (preg_match('#^https?://#i', $candidate)) $data = $candidate;
}

final class CDDQR {
    private const PAD0 = 0xEC;
    private const PAD1 = 0x11;
    private const G15 = 0x537;
    private const G18 = 0x1F25;
    private const G15_MASK = 0x5412;

    private static array $exp = [];
    private static array $log = [];

    private static array $rsL = [
        1 => [[1,26,19]],
        2 => [[1,44,34]],
        3 => [[1,70,55]],
        4 => [[1,100,80]],
        5 => [[1,134,108]],
        6 => [[2,86,68]],
        7 => [[2,98,78]],
        8 => [[2,121,97]],
        9 => [[2,146,116]],
        10 => [[2,86,68],[2,87,69]],
    ];

    private static array $patternPos = [
        1=>[], 2=>[6,18], 3=>[6,22], 4=>[6,26], 5=>[6,30],
        6=>[6,34], 7=>[6,22,38], 8=>[6,24,42], 9=>[6,26,46], 10=>[6,28,50],
    ];

    public static function svg(string $text, int $scale=8, int $margin=4): string {
        self::initGF();
        $bytes = array_values(unpack('C*', $text));
        $version = self::chooseVersion(count($bytes));
        $codewords = self::createCodewords($bytes, $version);
        $best = null; $bestScore = PHP_INT_MAX;
        for ($mask=0; $mask<8; $mask++) {
            $m = self::buildMatrix($version, $codewords, $mask, true);
            $score = self::lostPoint($m);
            if ($score < $bestScore) { $bestScore = $score; $best = $mask; }
        }
        $m = self::buildMatrix($version, $codewords, $best ?? 0, false);
        $n = count($m); $size = ($n + 2*$margin) * $scale;
        $path = '';
        for ($r=0; $r<$n; $r++) {
            for ($c=0; $c<$n; $c++) {
                if ($m[$r][$c]) {
                    $x = ($c+$margin)*$scale; $y = ($r+$margin)*$scale;
                    $path .= "M{$x},{$y}h{$scale}v{$scale}h-{$scale}z";
                }
            }
        }
        return '<?xml version="1.0" encoding="UTF-8"?>'
            . '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '.$size.' '.$size.'" width="'.$size.'" height="'.$size.'" shape-rendering="crispEdges">'
            . '<rect width="100%" height="100%" fill="#fff"/>'
            . '<path d="'.$path.'" fill="#000"/>'
            . '</svg>';
    }

    private static function initGF(): void {
        if (self::$exp) return;
        self::$exp = array_fill(0, 512, 0);
        self::$log = array_fill(0, 256, 0);
        $x=1;
        for ($i=0;$i<255;$i++) {
            self::$exp[$i]=$x; self::$log[$x]=$i;
            $x <<= 1; if ($x & 0x100) $x ^= 0x11d;
        }
        for ($i=255;$i<512;$i++) self::$exp[$i]=self::$exp[$i-255];
    }

    private static function gmul(int $a, int $b): int {
        if ($a===0 || $b===0) return 0;
        return self::$exp[self::$log[$a]+self::$log[$b]];
    }

    private static function rsGenerator(int $degree): array {
        $poly=[1];
        for ($i=0;$i<$degree;$i++) {
            $next=array_fill(0,count($poly)+1,0);
            for ($j=0;$j<count($poly);$j++) {
                $next[$j] ^= $poly[$j];
                $next[$j+1] ^= self::gmul($poly[$j], self::$exp[$i]);
            }
            $poly=$next;
        }
        return $poly;
    }

    private static function rsEncode(array $data, int $eccLen): array {
        $gen=self::rsGenerator($eccLen);
        $res=array_merge($data,array_fill(0,$eccLen,0));
        for ($i=0;$i<count($data);$i++) {
            $factor=$res[$i];
            if ($factor===0) continue;
            for ($j=0;$j<count($gen);$j++) $res[$i+$j] ^= self::gmul($gen[$j],$factor);
        }
        return array_slice($res,-$eccLen);
    }

    private static function chooseVersion(int $len): int {
        for ($v=1;$v<=10;$v++) {
            $cap=0; foreach(self::$rsL[$v] as [$count,$total,$data]) $cap += $count*$data;
            $lengthBits = $v < 10 ? 8 : 16;
            if (4+$lengthBits+$len*8 <= $cap*8) return $v;
        }
        throw new RuntimeException('URL longa demais para o gerador local de QR Code.');
    }

    private static function putBits(array &$bits, int $val, int $len): void {
        for ($i=$len-1;$i>=0;$i--) $bits[] = (($val >> $i) & 1) === 1;
    }

    private static function createCodewords(array $bytes, int $version): array {
        $blocks=[]; $dataCap=0;
        foreach(self::$rsL[$version] as [$count,$total,$data]) {
            for($i=0;$i<$count;$i++) $blocks[]=['total'=>$total,'data'=>$data];
            $dataCap += $count*$data;
        }
        $bits=[];
        self::putBits($bits, 0x4, 4); // byte mode
        self::putBits($bits, count($bytes), $version < 10 ? 8 : 16);
        foreach($bytes as $b) self::putBits($bits,$b,8);
        $capacity=$dataCap*8;
        $terminator=min(4,max(0,$capacity-count($bits)));
        for($i=0;$i<$terminator;$i++) $bits[]=false;
        while(count($bits)%8) $bits[]=false;
        $data=[];
        for($i=0;$i<count($bits);$i+=8){$v=0;for($j=0;$j<8;$j++)$v=($v<<1)|($bits[$i+$j]?1:0);$data[]=$v;}
        $pad=self::PAD0; while(count($data)<$dataCap){$data[]=$pad;$pad=($pad===self::PAD0)?self::PAD1:self::PAD0;}

        $dc=[];$ec=[];$offset=0;$maxD=0;$maxE=0;
        foreach($blocks as $b){
            $d=array_slice($data,$offset,$b['data']);$offset+=$b['data'];
            $e=self::rsEncode($d,$b['total']-$b['data']);
            $dc[]=$d;$ec[]=$e;$maxD=max($maxD,count($d));$maxE=max($maxE,count($e));
        }
        $out=[];
        for($i=0;$i<$maxD;$i++)foreach($dc as $d)if($i<count($d))$out[]=$d[$i];
        for($i=0;$i<$maxE;$i++)foreach($ec as $e)if($i<count($e))$out[]=$e[$i];
        return $out;
    }

    private static function buildMatrix(int $version, array $data, int $mask, bool $test): array {
        $n=17+4*$version;
        $m=array_fill(0,$n,array_fill(0,$n,null));
        self::finder($m,0,0); self::finder($m,$n-7,0); self::finder($m,0,$n-7);
        self::alignment($m,$version);
        self::timing($m);
        self::typeInfo($m,$mask,$test);
        if($version>=7) self::versionInfo($m,$version,$test);
        self::mapData($m,$data,$mask);
        return $m;
    }

    private static function finder(array &$m,int $row,int $col):void{
        $n=count($m);
        for($r=-1;$r<=7;$r++)for($c=-1;$c<=7;$c++){
            $rr=$row+$r;$cc=$col+$c;if($rr<0||$rr>=$n||$cc<0||$cc>=$n)continue;
            $m[$rr][$cc]=($r>=0&&$r<=6&&($c===0||$c===6))||($c>=0&&$c<=6&&($r===0||$r===6))||($r>=2&&$r<=4&&$c>=2&&$c<=4);
        }
    }

    private static function alignment(array &$m,int $version):void{
        $pos=self::$patternPos[$version] ?? [];
        foreach($pos as $r)foreach($pos as $c){
            if($m[$r][$c]!==null)continue;
            for($dr=-2;$dr<=2;$dr++)for($dc=-2;$dc<=2;$dc++)$m[$r+$dr][$c+$dc]=abs($dr)===2||abs($dc)===2||($dr===0&&$dc===0);
        }
    }

    private static function timing(array &$m):void{
        $n=count($m);
        for($i=8;$i<$n-8;$i++)if($m[$i][6]===null)$m[$i][6]=($i%2===0);
        for($i=8;$i<$n-8;$i++)if($m[6][$i]===null)$m[6][$i]=($i%2===0);
    }

    private static function bchDigit(int $d):int{$n=0;while($d!==0){$n++;$d>>=1;}return $n;}
    private static function bchTypeInfo(int $data):int{
        $d=$data<<10; while(self::bchDigit($d)-self::bchDigit(self::G15)>=0)$d^=self::G15<<(self::bchDigit($d)-self::bchDigit(self::G15));
        return (($data<<10)|$d)^self::G15_MASK;
    }
    private static function bchTypeNumber(int $data):int{
        $d=$data<<12; while(self::bchDigit($d)-self::bchDigit(self::G18)>=0)$d^=self::G18<<(self::bchDigit($d)-self::bchDigit(self::G18));
        return ($data<<12)|$d;
    }
    private static function typeInfo(array &$m,int $mask,bool $test):void{
        $n=count($m); $bits=self::bchTypeInfo((1<<3)|$mask); // L = 1
        for($i=0;$i<15;$i++){
            $mod=!$test && ((($bits>>$i)&1)===1);
            if($i<6)$m[$i][8]=$mod; elseif($i<8)$m[$i+1][8]=$mod; else $m[$n-15+$i][8]=$mod;
        }
        for($i=0;$i<15;$i++){
            $mod=!$test && ((($bits>>$i)&1)===1);
            if($i<8)$m[8][$n-$i-1]=$mod; elseif($i<9)$m[8][15-$i]=$mod; else $m[8][15-$i-1]=$mod;
        }
        $m[$n-8][8]=!$test;
    }
    private static function versionInfo(array &$m,int $version,bool $test):void{
        $n=count($m);$bits=self::bchTypeNumber($version);
        for($i=0;$i<18;$i++){$mod=!$test&&((($bits>>$i)&1)===1);$m[intdiv($i,3)][$i%3+$n-11]=$mod;}
        for($i=0;$i<18;$i++){$mod=!$test&&((($bits>>$i)&1)===1);$m[$i%3+$n-11][intdiv($i,3)]=$mod;}
    }

    private static function mask(int $p,int $i,int $j):bool{
        return match($p){
            0=>(($i+$j)%2)===0,
            1=>($i%2)===0,
            2=>($j%3)===0,
            3=>(($i+$j)%3)===0,
            4=>((intdiv($i,2)+intdiv($j,3))%2)===0,
            5=>((($i*$j)%2)+(($i*$j)%3))===0,
            6=>(((($i*$j)%2)+(($i*$j)%3))%2)===0,
            7=>(((($i*$j)%3)+(($i+$j)%2))%2)===0,
        };
    }

    private static function mapData(array &$m,array $data,int $mask):void{
        $n=count($m);$inc=-1;$row=$n-1;$bit=7;$byte=0;
        for($col=$n-1;$col>0;$col-=2){
            if($col===6)$col--;
            while(true){
                for($c=0;$c<2;$c++){
                    $cc=$col-$c;
                    if($m[$row][$cc]===null){
                        $dark=false; if($byte<count($data))$dark=((($data[$byte]>>$bit)&1)===1);
                        if(self::mask($mask,$row,$cc))$dark=!$dark;
                        $m[$row][$cc]=$dark; $bit--; if($bit<0){$byte++;$bit=7;}
                    }
                }
                $row+=$inc; if($row<0||$row>=$n){$row-=$inc;$inc=-$inc;break;}
            }
        }
    }

    private static function lostPoint(array $m):int{
        $n=count($m);$score=0;
        // N1: linhas/colunas com 5+ módulos iguais
        for($pass=0;$pass<2;$pass++){
            for($a=0;$a<$n;$a++){
                $runColor=null;$run=0;
                for($b=0;$b<$n;$b++){
                    $v=$pass===0?$m[$a][$b]:$m[$b][$a];
                    if($v===$runColor)$run++; else { if($run>=5)$score+=3+($run-5);$runColor=$v;$run=1; }
                }
                if($run>=5)$score+=3+($run-5);
            }
        }
        // N2: blocos 2x2 iguais
        for($r=0;$r<$n-1;$r++)for($c=0;$c<$n-1;$c++)if($m[$r][$c]===$m[$r+1][$c]&&$m[$r][$c]===$m[$r][$c+1]&&$m[$r][$c]===$m[$r+1][$c+1])$score+=3;
        // N3: padrão 1011101 cercado por 4 brancos
        $p1='10111010000';$p2='00001011101';
        for($r=0;$r<$n;$r++){
            $s='';for($c=0;$c<$n;$c++)$s.=$m[$r][$c]?'1':'0';$score+=40*(substr_count($s,$p1)+substr_count($s,$p2));
        }
        for($c=0;$c<$n;$c++){
            $s='';for($r=0;$r<$n;$r++)$s.=$m[$r][$c]?'1':'0';$score+=40*(substr_count($s,$p1)+substr_count($s,$p2));
        }
        // N4: proporção de módulos escuros
        $dark=0;foreach($m as $row)foreach($row as $v)if($v)$dark++;
        $percent=100*$dark/($n*$n);$score+=(int)(abs($percent-50)/5)*10;
        return $score;
    }
}

try {
    echo CDDQR::svg($data, 8, 4);
} catch (Throwable $e) {
    http_response_code(500);
    echo '<svg xmlns="http://www.w3.org/2000/svg" width="420" height="420" viewBox="0 0 420 420"><rect width="100%" height="100%" fill="#fff"/><text x="210" y="200" text-anchor="middle" font-family="Arial" font-size="18" fill="#900">Erro ao gerar QR Code</text><text x="210" y="230" text-anchor="middle" font-family="Arial" font-size="12" fill="#555">'.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8').'</text></svg>';
}
