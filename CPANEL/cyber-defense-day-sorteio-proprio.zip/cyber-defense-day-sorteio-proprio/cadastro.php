<?php
require_once __DIR__ . '/lib.php';
ensure_data_files();

$registered = null;
$error = '';

// Se já cadastrou neste navegador, exibe o mesmo ID.
if (!empty($_COOKIE['cdd_registration_id'])) {
    $cookieId = $_COOKIE['cdd_registration_id'];
    foreach (read_json_locked('participants') as $p) {
        if (($p['id'] ?? '') === $cookieId) { $registered = $p; break; }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$registered) {
    if (!REGISTRATION_OPEN) {
        $error = 'As inscrições estão encerradas.';
    } else {
        $first = clean_name($_POST['first_name'] ?? '');
        $last = clean_name($_POST['last_name'] ?? '');
        if (!valid_name($first) || !valid_name($last)) {
            $error = 'Informe nome e sobrenome válidos.';
        } else {
            $registered = mutate_json_locked('participants', function (&$participants) use ($first,$last) {
                $id = generate_unique_id($participants);
                $item = [
                    'id'=>$id,
                    'first_name'=>$first,
                    'last_name'=>$last,
                    'name'=>$first . ' ' . $last,
                    'created_at'=>date('c')
                ];
                $participants[] = $item;
                return $item;
            });
            setcookie('cdd_registration_id', $registered['id'], [
                'expires'=>time()+60*60*24*30,
                'path'=>'/',
                'httponly'=>true,
                'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                'samesite'=>'Lax'
            ]);
        }
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cadastro | <?=htmlspecialchars(EVENT_NAME)?></title>
<style>
:root{--bg:#050a12;--panel:rgba(7,18,31,.94);--line:#1d4f78;--cyan:#58d9ff;--blue:#0b82ff;--text:#eff9ff;--muted:#93abc1;--danger:#ff8796;--ok:#54dda7}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;font-family:Inter,Segoe UI,Arial,sans-serif;color:var(--text);background:radial-gradient(circle at 50% 0,#0b3560 0,#06111f 34%,#03070d 75%)}body:before{content:"";position:fixed;inset:0;background:url('assets/brand-banner.png') center/cover no-repeat;opacity:.12;pointer-events:none}.wrap{width:min(560px,100%);position:relative}.brand{text-align:center;margin-bottom:16px}.brand img{width:118px;margin:0 auto 12px;filter:drop-shadow(0 0 18px rgba(48,187,255,.35))}.brand h1{margin:0;font-size:clamp(28px,8vw,48px);line-height:1;color:white}.brand h1 span{color:var(--cyan)}.brand p{margin:8px 0 0;color:#b9d6eb}.card{background:linear-gradient(180deg,rgba(8,19,33,.95),rgba(5,12,22,.97));border:1px solid rgba(83,172,229,.28);border-radius:24px;padding:24px;box-shadow:0 28px 70px rgba(0,0,0,.5)}label{display:block;font-size:13px;font-weight:800;color:#c7e1f5;margin:14px 0 7px}input{width:100%;padding:14px 15px;background:#06121f;border:1px solid #224d70;border-radius:13px;color:white;font-size:17px;outline:none}input:focus{border-color:var(--cyan);box-shadow:0 0 0 3px rgba(63,195,255,.1)}button{width:100%;margin-top:18px;padding:15px;border:0;border-radius:14px;background:linear-gradient(135deg,var(--blue),var(--cyan));color:#03101b;font-size:17px;font-weight:1000;cursor:pointer}.error{padding:12px;border:1px solid #753647;background:#28111a;border-radius:12px;color:#ffd1d7;margin-bottom:12px}.success{text-align:center}.success .tag{font-size:12px;letter-spacing:.18em;text-transform:uppercase;color:var(--cyan);font-weight:900}.id{margin:18px 0 10px;font-size:clamp(40px,11vw,68px);font-weight:1000;letter-spacing:.05em;color:var(--cyan);text-shadow:0 0 20px rgba(66,201,255,.28);word-break:break-word}.name{font-size:24px;font-weight:900}.tip{margin-top:20px;padding:13px;border:1px solid #214a69;background:#071522;border-radius:13px;color:#b9cfdf;font-size:14px;line-height:1.45}.closed{text-align:center;color:#ffd3d9}.footer{text-align:center;margin-top:14px;color:#7794ad;font-size:12px}
</style></head><body><div class="wrap"><div class="brand"><img src="assets/brand-emblem.png" alt="Brasão"><h1>CYBER <span>DEFENSE DAY</span></h1><p>Cadastro para o sorteio oficial</p></div><div class="card">
<?php if ($registered): ?>
<div class="success"><div class="tag">Cadastro realizado</div><div class="id"><?=htmlspecialchars($registered['id'])?></div><div class="name"><?=htmlspecialchars($registered['name'])?></div><div class="tip">Este é o seu ID oficial para o sorteio. <strong>Guarde esta tela.</strong> Se o seu ID for sorteado, ele aparecerá no telão junto com o seu nome.</div></div>
<?php elseif (!REGISTRATION_OPEN): ?><div class="closed"><h2>Inscrições encerradas</h2><p>O cadastro para o sorteio não está mais disponível.</p></div>
<?php else: ?>
<?php if ($error): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post" autocomplete="on"><label>Nome</label><input name="first_name" required maxlength="80" autocomplete="given-name" placeholder="Digite seu nome"><label>Sobrenome</label><input name="last_name" required maxlength="80" autocomplete="family-name" placeholder="Digite seu sobrenome"><button type="submit">GERAR MEU ID</button></form>
<?php endif; ?>
</div><div class="footer">CYBER DEFENSE DAY • Sorteio Oficial</div></div></body></html>
