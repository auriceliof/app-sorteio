CYBER DEFENSE DAY - SORTEIO PRÓPRIO

REQUISITOS
- Hospedagem PHP 7.4+ (recomendado PHP 8.x)
- Permissão de gravação na pasta data/

INSTALAÇÃO
1. Envie toda a pasta para o seu cPanel/servidor PHP.
2. Garanta permissão de escrita para a pasta data/ (normalmente 755; se necessário, ajuste conforme o servidor).
3. Abra index.php no navegador.
4. Senha inicial do painel: Cyber@2026!
5. TROQUE essa senha em config.php antes do evento.

FUNCIONAMENTO
- O painel mostra um QR Code apontando para cadastro.php.
- O participante informa Nome e Sobrenome.
- O sistema gera um ID único no padrão CDD-XXXXXX.
- O mesmo navegador recebe e mantém o ID via cookie.
- O painel atualiza a quantidade de participantes automaticamente.
- Ao clicar SORTEAR, o servidor escolhe um participante usando random_int().
- O telão exibe ID sorteado + nome.
- Por padrão, uma pessoa sorteada não participa novamente.

URL PÚBLICA
O sistema detecta automaticamente a URL do cadastro. Se sua hospedagem usar proxy, subpasta incomum ou URL diferente, defina PUBLIC_REGISTRATION_URL em config.php.

OBSERVAÇÃO DO QR CODE
A imagem do QR Code é gerada pelo serviço público api.qrserver.com. O endereço de cadastro também aparece em texto para uso manual caso o serviço de QR esteja indisponível.
