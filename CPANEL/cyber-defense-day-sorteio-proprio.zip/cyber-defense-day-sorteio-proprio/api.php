<?php
require_once __DIR__ . '/lib.php';
start_secure_session();
$action = $_GET['action'] ?? '';

if ($action === 'status') {
    require_admin();
    $participants = read_json_locked('participants');
    $winners = read_json_locked('winners');
    json_response([
        'ok'=>true,
        'count'=>count($participants),
        'winners'=>count($winners),
        'latest'=>array_slice(array_reverse($participants),0,8),
        'registration_url'=>registration_url()
    ]);
}

if ($action === 'draw') {
    require_admin();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['ok'=>false,'error'=>'Método inválido.'],405);
    $participants = read_json_locked('participants');
    $winners = read_json_locked('winners');
    if (!$participants) json_response(['ok'=>false,'error'=>'Nenhum participante cadastrado.'],400);
    $won = [];
    foreach ($winners as $w) $won[$w['id'] ?? ''] = true;
    $eligible = array_values(array_filter($participants, function($p) use ($won){
        return ALLOW_REPEAT_WINNERS || empty($won[$p['id'] ?? '']);
    }));
    if (!$eligible) json_response(['ok'=>false,'error'=>'Todos os participantes já foram sorteados.'],400);
    $winner = $eligible[random_int(0,count($eligible)-1)];
    $winner['drawn_at'] = date('c');
    mutate_json_locked('winners', function (&$items) use ($winner) { $items[]=$winner; return true; });
    json_response(['ok'=>true,'winner'=>$winner,'remaining'=>count($eligible)-1]);
}

if ($action === 'history') {
    require_admin();
    json_response(['ok'=>true,'items'=>array_reverse(read_json_locked('winners'))]);
}

if ($action === 'delete_participant') {
    require_admin();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['ok'=>false,'error'=>'Método inválido.'],405);
    $id = $_POST['id'] ?? '';
    mutate_json_locked('participants', function (&$items) use ($id) {
        $items = array_values(array_filter($items, fn($p)=>($p['id']??'')!==$id));
        return true;
    });
    json_response(['ok'=>true]);
}

if ($action === 'reset_winners') {
    require_admin();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['ok'=>false,'error'=>'Método inválido.'],405);
    mutate_json_locked('winners', function (&$items){$items=[];return true;});
    json_response(['ok'=>true]);
}

json_response(['ok'=>false,'error'=>'Ação inválida.'],404);
