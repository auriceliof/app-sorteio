<?php
// CYBER DEFENSE DAY - Configuração do sorteio
// TROQUE a senha antes de publicar.
define('ADMIN_PASSWORD', 'Cyber@2026!');
define('EVENT_NAME', 'CYBER DEFENSE DAY');
define('EVENT_SUBTITLE', 'Sorteio Oficial');
define('ID_PREFIX', 'CDD');
define('ALLOW_REPEAT_WINNERS', false);
define('REGISTRATION_OPEN', true);

// Se deixar vazio, o sistema detecta automaticamente a URL do cadastro.
// Exemplo: https://seudominio.com/sorteio/cadastro.php
define('PUBLIC_REGISTRATION_URL', '');
